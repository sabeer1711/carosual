import { Component, OnInit } from '@angular/core';
import { animation, trigger, animate } from "@angular/animations";

@Component({
  selector: 'app-sample',
  templateUrl: './sample.component.html',
  styleUrls: ['./sample.component.scss'],
  animations:[
    trigger('left',[

    ])
  ]
})
export class SampleComponent implements OnInit {

  constructor() {
  }
  carousels = [
    {
      "heading":"Most populer consulting agency 1",
      "content":"Raising a heavy fur muff that covered the whole of her lower arm towards the viewer.",
      "button":"Discover More",
      "imageUrl": "../../assets/slide-1.jpg"
    },

    {
      "heading":"Most populer consulting agency 2",
      "content":"Raising a heavy fur muff that covered the whole of her lower arm towards the viewer.",
      "button":"Discover More",
      "imageUrl":"../../assets/slide-2.jpg"
    },
    {
      "heading":"Most populer consulting agency 3",
      "content":"Raising a heavy fur muff that covered the whole of her lower arm towards the viewer.",
      "button":"Discover More",
      "imageUrl":"../../assets/slide-2.jpg"
    },
    {
      "heading":"Most populer consulting agency 4",
      "content":"Raising a heavy fur muff that covered the whole of her lower arm towards the viewer.",
      "button":"Discover More",
      "imageUrl": "../../assets/slide-1.jpg"
    },

  ]
  ngOnInit() {
  }


}
